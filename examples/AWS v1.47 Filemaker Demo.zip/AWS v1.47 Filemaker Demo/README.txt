APORIA Works Registration - Filemaker Demo

DISCLAIMER
----------

These files are provided with absolutely NO WARRANTY.

They are simply intended to illustrate how Filemaker SQL queries can be used from PHP to integrate the APORIA Works Registration php library.

This is NOT A FULL REGISTRATION SYSTEM -- you likely track a lot more data in your setup.  Please examine how this file is put together, and then modify your own solution accordingly.



Files:
-----
CWR_Lookup_Tables.fmp12			This contains the CISAC lookup tables
Works Data.fmp12				This contains an example work
DEMO Works Registration.fmp12	This contains the GUI layouts and scripts

libphp5.mac.dylib				This is the php plugin, available on the Monkeybread website

php/AporiaWorksRegistration.php
php/cwr-lib.php
php/fm_functionlib.php			Some useful Filemaker/php SQL helper functions
php/TIS-data.php			


Instructions:
------------

1. You will need to download the MBS plugin here:
https://www.monkeybreadsoftware.de/filemaker/download.shtml

2. I have included libphp5.mac.dylib, which is the Mac version of PHP.  If you are on a PC, you will need to download the correct version of PHP from the MBS website.

3. Open 'DEMO Works Registration.fmp12', and modify the 'startup' script if required (to use the PC version of php, etc.)

4. Use the CWR layout to export the current found set to CWR.  Obviously not all features are mapped/included, but this should be enough to get you started.

5. To build a complete CWR system, you also need to create an import script that will update your works database with ISWCs and society codes.