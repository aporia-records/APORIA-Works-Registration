<?
/* fm_funcionlib.php */
/*
$arr = array(0 => array(id=>1,name=>"cat 1"),
       1 => array(id=>2,name=>"cat 2"),
       2 => array(id=>3,name=>"cat 1"));

print_r(search($arr, 'name', 'cat 1'));
*/

//iconv_set_encoding("internal_encoding", "Macintosh");

function search($array, $key, $value)
{
    $results = array();

    if (is_array($array))
    {
        if (isset($array[$key]) && $array[$key] == $value)
            $results[] = $array;

        foreach ($array as $subarray)
            $results = array_merge($results, search($subarray, $key, $value));
    }

    return $results;
}

/* Submit an SQL query to FileMaker and return an associative array */
function fm_getasarray($query, $debug = false)
{
	$query['select'] = str_replace(' ', '', $query['select']);	// Remove spaces from select
	$field_name_arr = explode(',', $query['select']);			// Explode select into array
	$query['select'] = implode(',' , $field_name_arr);			// Implode select back into a string (just to ensure everything matches)
	
	// Build SQL Query
	$sql = "SELECT {$query['select']} FROM {$query['from']}";
	if(isset($query['where'])) $sql .= " WHERE {$query['where']}";
	if(isset($query['order_by'])) $sql .=" ORDER BY {$query['order_by']}";

	if($debug) printf("SQL: %s\n\n", $sql);

	// Filemaker function Abs() returns 1 if system is macintosh; 2 if windows
	switch(FMEvaluate('Get(SystemPlatform)')) // Returns -1 for PPC Mac; 1 for Intel Mac; or 2 for Windows
	{
	    case '1':
	    case '-1':    $charset = 'MacRoman';	break;

	    case '2':    $charset =  'cp1252';		break;
	}
/*
$col = iconv('ISO-8859-1', $charset, '|');
$row = iconv('ISO-8859-1', $charset, '§');
*/
//	printf("col: %s\nrow: %s (§)\n", 124, 0xA7);
//	mb_convert_encoding
//	$results = mb_convert_encoding(fm_sql_select($sql), 'ISO-8859-1', $charset);
//$results = iconv($charset, 'ISO-8859-1//IGNORE', fm_sql_select($sql, $col, $row));

	/* Convert to ISO-8859-1 for PHP when receiving SQL table back from Filemaker: */
//	$value = iconv('Windows-1252', 'ISO-8859-1//TRANSLIT', $value);
//	$value = iconv('macintosh', 'ISO-8859-1//TRANSLIT', $value);

	$results = FMExecuteSQL($sql, 124, 0xA7);
//	if($debug) echo $results;
//	$results = fm_sql_select($sql, 124, 0xA7);
//	$results = iconv('UTF-8', 'ISO-8859-1//IGNORE', fm_sql_select($sql, 124, 0xA7));

//	echo $results;

//	$error = fm_get_last_error();
	$error = FMEvaluate('MBS( "FM.ExecuteSQL.LastError" )');
	if($error != 0) {
		printf("\n*** Filemaker/SQL Error ***\n%s\nsql = %s\n", $error, $sql);
//		echo $error;
		return(false);
	}

	$records_arr = explode("\xA7", $results);
	$new_records_arr = array();
	
//	setlocale(LC_ALL, 'en_CA');
	foreach($records_arr as $record) 
	{
//		$record = iconv('ISO-8859-1', 'ASCII//TRANSLIT', $record);
//		$record = iconv($charset, 'ISO-8859-1//TRANSLIT', $record);
		$values = explode('|', $record);

		if(count($field_name_arr) == count($values))
		{
			$record_arr = array_combine($field_name_arr, $values);
	//		foreach($record_arr as $record) $record = iconv('macintosh', 'ISO-8859-1//TRANSLIT', $record);
			array_push($new_records_arr, $record_arr);
		}
	}
	
	return($new_records_arr);
}
?>